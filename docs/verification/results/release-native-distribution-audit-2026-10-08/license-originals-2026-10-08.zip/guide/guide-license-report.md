# DIR-Simulator ガイド同梱資産のライセンス照合

検証日: 2026-10-08 UTC  
対象: `hideki-ozu/DIR-Simulator` / `d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b`

## 結論

- 既存のガイド向け第三者ライセンス原文 **7件は、該当する公式配布元の原文とバイト単位で一致**した
- 追加すべき通知が1件ある。MkDocs 1.6.1のBootstrap bundleには **Popper 2.11.8（MIT）** が含まれるが、リポジトリ内のガイド用ライセンス集合・出典一覧にPopperがない。公式原文を `additional-notices/popper-2.11.8-MIT.txt` に添付した
- `lunr-languages` は **1.12.0 / MPL-1.1** と特定できた。出典の `master` を固定コミットへ変更すると再現性が上がる
- これは指定コミットと公式MkDocs配布物の静的照合。実際のGitHub Pages公開物・Release ZIP・利用者に渡る最終成果物は未検査であり、配布全体の遵守を保証するものではない

## 検証範囲と方法

`requirements-guide.txt` は `mkdocs==1.6.1`、`mkdocs.yml` は標準 `mkdocs` テーマ、日本語検索、`highlightjs: false` を指定している。CIはこのrequirementsをインストールしてMkDocsを実行し、`build/guide` をPagesへ渡す。テーマ変更や第三者資産の再加工を行う工程は当該ワークフローにはない

公式PyPIのMkDocs 1.6.1 source distributionをダウンロードし、公開SHA-256 `7b432f01d928c084353ab39c57282f29f92136665bdd6abf7c1ec8d822ef86f2` と一致することを確認した。アーカイブをデータとして読み、公式Gitタグ・npm配布物との比較を行った。パッケージのインストール、プロジェクトのビルド、ダウンロードしたコードの実行、リポジトリ変更はしていない

## 原文照合結果

| リポジトリ内のファイル | 対象・ライセンス | 結果・公式原文 |
| --- | --- | --- |
| `bootstrap-MIT.txt` | Bootstrap 5.3.2 / MIT | 完全一致。[v5.3.2 LICENSE](https://raw.githubusercontent.com/twbs/bootstrap/v5.3.2/LICENSE) |
| `bootswatch-MIT.txt` | Bootswatch 5.3.2 / MIT | 完全一致。[v5.3.2 LICENSE](https://raw.githubusercontent.com/thomaspark/bootswatch/v5.3.2/LICENSE) |
| `fontawesome-license.txt` | Font Awesome Free 6.5.1 / MIT・OFL-1.1・CC-BY-4.0 | 完全一致。[6.5.1 LICENSE.txt](https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.5.1/LICENSE.txt) |
| `lunr-MIT.txt` | lunr.js 2.3.9 / MIT | 完全一致。[v2.3.9 LICENSE](https://raw.githubusercontent.com/olivernn/lunr.js/v2.3.9/LICENSE) |
| `lunr-languages-MPL.txt` | lunr-languages 1.12.0 / MPL-1.1 | 完全一致。[固定コミット LICENSE](https://raw.githubusercontent.com/MihaiValentin/lunr-languages/f313734d145048be2f3681b756f9bf925aa299a1/LICENSE) |
| `tinysegmenter-license.txt` | TinySegmenter 0.1 / BSD-3-Clause | 完全一致。[公式 LICENCE.txt](http://chasen.org/~taku/software/TinySegmenter/LICENCE.txt)。HTTP原文を取得して確認 |
| `mkdocs-BSD.txt` | MkDocs 1.6.1 / BSD-2-Clause | 完全一致。[1.6.1 LICENSE](https://raw.githubusercontent.com/mkdocs/mkdocs/1.6.1/LICENSE) |

上記7件のSHA-256、サイズ、照合元URLは `guide-license-report.json` に収録した

## 同梱資産のバージョン確認

### Bootstrap / Bootswatch / Popper

- MkDocsの `css/bootstrap.min.css` はBootswatch 5.3.2 Ceruleanの公式ファイルと完全一致。Bootstrap 5.3.2とBootswatchの著作権ヘッダーが残っている
- `js/bootstrap.bundle.min.js` はBootstrap 5.3.2の公式ファイルと完全一致
- 同bundleのsource mapには `@popperjs/core` の55ソースファイルがある。55件すべて公式npm **2.11.8** と内容一致。Bootstrap 5.3.2の公式package-lockも2.11.8を指し、取得したnpmアーカイブはそのSHA-512 integrityに一致した
- Popperの著作権は **2019 Federico Zivolo**。MkDocs同梱bundle/source mapにはこの著作権表示・MIT許諾本文がなく、指定コミットの `docs/guide/assets/licenses/` にもPopperの原文がない
- 対応案: 添付したPopper MIT原文をガイド用ライセンス資産に追加し、出典・バージョンを記録する。変更後の最終公開物にもそのファイルが含まれることを別途検証する

一次資料: [Bootstrap 5.3.2 bundle](https://github.com/twbs/bootstrap/blob/v5.3.2/dist/js/bootstrap.bundle.min.js)、[package-lock](https://github.com/twbs/bootstrap/blob/v5.3.2/package-lock.json)、[Popper 2.11.8 MIT原文](https://raw.githubusercontent.com/floating-ui/floating-ui/v2.11.8/LICENSE.md)

### Font Awesome Free 6.5.1

- 4つのCSS（fontawesome、brands、solid、v4-font-face）は公式6.5.1 Gitタグと完全一致
- 8つのTTF/WOFF2は公式 **`@fortawesome/fontawesome-free` 6.5.1 npm配布物と全件完全一致**した
- Gitタグのフォントバイナリとはハッシュが異なるが、npm公式配布物との一致により出典確認は解決済み。参考確認として、TTFとGitタグとの差は `head` のチェックサム・日時フィールドだけだった。TTF内部のバージョンも6.5.1
- 現テーマはCSSとフォントを同梱し、Font AwesomeのSVG/JSアイコン資産は同梱していない。CSSはMIT、TTF/WOFF2はOFL-1.1として扱う。CC-BY-4.0はSVG/JS形式のアイコンに適用されるため、すべてのFont Awesome資産を単一ライセンスにまとめない
- 既存の複合ライセンス原文を維持する。OFLでは著作権・ライセンスの同梱、フォント単体販売制限、改変フォントのReserved Font Name制限等がある。これによりDIR-Simulator全体をOFLにする必要はない

一次資料: [6.5.1ライセンス](https://github.com/FortAwesome/Font-Awesome/blob/6.5.1/LICENSE.txt)、[公式npm配布物](https://registry.npmjs.org/@fortawesome/fontawesome-free/-/fontawesome-free-6.5.1.tgz)

### lunr.js / lunr-languages / TinySegmenter

- 日本語検索用 `lunr.ja.js`、`lunr.stemmer.support.js`、`tinyseg.js` はlunr-languages **1.12.0** のnpm配布物とGitタグ（コミット `f313734d145048be2f3681b756f9bf925aa299a1`）の両方に完全一致
- `tinyseg.js` 内部のヘッダーはTinySegmenter **0.1** と明記。BSD原文も著作者の公式配布ページから照合済み
- `lunr.js` の版表記は **2.3.9**。公式2.3.9コードとの差はコメントの誤記 `enviroments` → `environments` の1か所のみで、実行コードの差はない。ただし、この変更を誰がいつ加えたかという履歴までは追跡していないため、ファイル全体の完全一致とは表現しない
- lunr.jsソースには2020年、公式LICENSEには2013年という著作権年の違いがあるが、どちらも上流どおり。原文を勝手に統一せずソースヘッダーも維持する
- `sources.txt` のlunr-languages `master` URLは固定コミットへ置き換えることを推奨

MPL-1.1では、対象ソースと通知・ライセンスを保持する。改変する場合やminify等を行い実行形式のみ配る場合は、3.1–3.6節の対象ソース提供、変更内容・日付記録、必要通知、ソースの入手先表示を確認する。現在の対象JSは非minifyの上流ソースに一致するが、最終配布物が未検査のため、すべての通知要件を満たしたとの断定はしない。3.7節は他のコードとのLarger Workを認めており、無関係なDIR-Simulator全体をMPLにする要求とは異なる

一次資料: [lunr-languages固定コミット](https://github.com/MihaiValentin/lunr-languages/tree/f313734d145048be2f3681b756f9bf925aa299a1)、[MPL-1.1原文](https://www.mozilla.org/en-US/MPL/1.1/)

## 配布時に確認すること

1. MIT/BSD資産の著作権・条件・免責事項と既存のソースヘッダーを残す。Popper原文を追加する
2. フォントはOFLの著作権・ライセンスを一緒に配布する
3. MPL対象の元ソース・ライセンス・必要通知を保持し、加工する場合は対応するソースと変更記録を用意する
4. `build/guide`、Pages公開物、オフライン配布ZIPで、通知ファイル・参照先・ソースが実際に届くことを確認する

## 未確定・対象外

- `requirements-guide.txt` はMkDocs本体だけを固定している。Python推移依存の実インストール版は固定されておらず、完全なPython環境ロックもない。現在の最新バージョンを当該ビルドの実依存だと推定することはしていない
- `readthedocs` テーマ用のFont Awesome 4、Roboto Slab、Lato、jQuery、html5shivは選択されたテーマの出力対象ではない。MkDocs配布物にあるだけで今回のガイドの依存に加えていない
- `highlightjs: false` のため、標準テーマのhighlight.js CDN資産を今回の出力依存に加えていない
- 実際の公開物、Release配布物、Pythonビルド環境全体の版一覧はこの照合では検査していない

本書は技術的な出典・原文照合と配布上の確認事項を整理したもので、法的見解ではない
