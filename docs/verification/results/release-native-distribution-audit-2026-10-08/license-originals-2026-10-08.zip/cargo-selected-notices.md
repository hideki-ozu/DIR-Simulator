# Cargo dependency notices verified from exact published crates

Audit target: hideki-ozu/DIR-Simulator @ d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b
All 42 archive SHA-256 values match Cargo.lock. No dependency code was executed.
This is a technical evidence collection, not a legal compliance guarantee.

## ascii 1.1.0
Published expression: Apache-2.0 OR MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/ascii/ascii-1.1.0.crate
SHA-256: d92bec98840b8f03a5ff5413de5293bfcd8bf96467cf5452609f939ec6f5de16

### LICENSE-MIT

MIT License

Copyright (c) 2017 Thomas Bahn and contributors
Copyright (c) 2014 The Rust Project Developers

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


### Additional source notices

- src/lib.rs:1: // Copyright 2013-2014 The Rust Project Developers. See the COPYRIGHT
- src/lib.rs:3: // http://rust-lang.org/COPYRIGHT.

## bitflags 2.13.2
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/bitflags/bitflags-2.13.2.crate
SHA-256: 3ded4057c258ba199e2d26386d3af3780957ecaee6c4ef4041c6b4b8b97c0b06

### LICENSE-MIT

Copyright (c) 2014 The Rust Project Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- src/lib.rs:1: // Copyright 2014 The Rust Project Developers. See the COPYRIGHT
- src/lib.rs:3: // http://rust-lang.org/COPYRIGHT.

## block-buffer 0.10.4
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/block-buffer/block-buffer-0.10.4.crate
SHA-256: 3078c7629b62d3f0439517fa394996acacc5cbc91c5a20d8c658e77abd503a71

### LICENSE-MIT

Copyright (c) 2018-2019 The RustCrypto Project Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## cfg-if 1.0.5
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/cfg-if/cfg-if-1.0.5.crate
SHA-256: 4e7648175b45a9a48536d676f68d918270699102aa8dab5496df06904c914600

### LICENSE-MIT

Copyright (c) 2014 Alex Crichton

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## chunked_transfer 1.5.0
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/chunked_transfer/chunked_transfer-1.5.0.crate
SHA-256: 6e4de3bc4ea267985becf712dc6d9eed8b04c953b3fcfb339ebc87acd9804901

### LICENSE-MIT

The MIT License (MIT)

Copyright (c) 2015 The tiny-http Contributors
Copyright (c) 2015 The rust-chunked-transfer Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


### Additional source notices

- src/decoder.rs:196:     /// Copyright (c) 2014 Sean McArthur

## cpufeatures 0.2.17
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/cpufeatures/cpufeatures-0.2.17.crate
SHA-256: 59ed5838eebb26a2bb2e58f6d5b5316989ae9d08bab10e0e6d103e656d1b0280

### LICENSE-MIT

Copyright (c) 2020-2025 The RustCrypto Project Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## crypto-common 0.1.7
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/crypto-common/crypto-common-0.1.7.crate
SHA-256: 78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a

### LICENSE-MIT

Copyright (c) 2021 RustCrypto Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## digest 0.10.7
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/digest/digest-0.10.7.crate
SHA-256: 9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292

### LICENSE-MIT

Copyright (c) 2017 Artyom Pavlov

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## errno 0.3.14
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/errno/errno-0.3.14.crate
SHA-256: 39cab71617ae0d63f51a36d69f866391735b51691dbda63cf6f96d042b63efeb

### LICENSE-MIT

Copyright (c) 2014 Chris Wong

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- src/hermit.rs:7: // Copyright 2015 The Rust Project Developers. See the COPYRIGHT
- src/hermit.rs:9: // http://rust-lang.org/COPYRIGHT.
- src/unix.rs:5: // Copyright 2015 The Rust Project Developers. See the COPYRIGHT
- src/unix.rs:7: // http://rust-lang.org/COPYRIGHT.
- src/wasi.rs:5: // Copyright 2015 The Rust Project Developers. See the COPYRIGHT
- src/wasi.rs:7: // http://rust-lang.org/COPYRIGHT.
- src/windows.rs:5: // Copyright 2014 The Rust Project Developers. See the COPYRIGHT
- src/windows.rs:7: // http://rust-lang.org/COPYRIGHT.

## generic-array 0.14.7
Published expression: MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/generic-array/generic-array-0.14.7.crate
SHA-256: 85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a

### LICENSE

The MIT License (MIT)

Copyright (c) 2015 Bartłomiej Kamiński

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## httpdate 1.0.3
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/httpdate/httpdate-1.0.3.crate
SHA-256: df3b46402a9d5adb4c86a0cf463f42e19994e3ee891101b1841f30a545cb49a9

### LICENSE-MIT

Copyright (c) 2016 Pyfisch

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


## itoa 1.0.18
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/itoa/itoa-1.0.18.crate
SHA-256: 8f42a60cbdf9a97f5d2305f08a87dc4e09308d1276d28c869c684d7777685682

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## libc 0.2.189
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/libc/libc-0.2.189.crate
SHA-256: 3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2

### LICENSE-MIT

Copyright (c) The Rust Project Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## linux-raw-sys 0.4.15
Published expression: Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/linux-raw-sys/linux-raw-sys-0.4.15.crate
SHA-256: d26c52dbd32dccf2d10cac7725f8eae5296885fb5703b261f7d0a0739ec807ab

### COPYRIGHT

Short version for non-lawyers:

`linux-raw-sys` is triple-licensed under Apache 2.0 with the LLVM Exception,
Apache 2.0, and MIT terms.


Longer version:

Copyrights in the `linux-raw-sys` project are retained by their contributors.
No copyright assignment is required to contribute to the `linux-raw-sys`
project.

Some files include code derived from Rust's `libstd`; see the comments in
the code for details.

Except as otherwise noted (below and/or in individual files), `linux-raw-sys`
is licensed under:

 - the Apache License, Version 2.0, with the LLVM Exception
   <LICENSE-Apache-2.0_WITH_LLVM-exception> or
   <http://llvm.org/foundation/relicensing/LICENSE.txt>
 - the Apache License, Version 2.0
   <LICENSE-APACHE> or
   <http://www.apache.org/licenses/LICENSE-2.0>,
 - or the MIT license
   <LICENSE-MIT> or
   <http://opensource.org/licenses/MIT>,

at your option.


### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- ORG_CODE_OF_CONDUCT.md:107:      in copyright violation or misattribution of any kind.

## log 0.4.34
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/log/log-0.4.34.crate
SHA-256: f9f8bd3e56ce4dfc153cf470fffbfa98c7620958b312ca5c3a4b8d5181fd13c6

### LICENSE-MIT

Copyright (c) 2014 The Rust Project Developers

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- src/lib.rs:1: // Copyright 2015 The Rust Project Developers. See the COPYRIGHT
- src/lib.rs:3: // http://rust-lang.org/COPYRIGHT.
- src/macros.rs:1: // Copyright 2014-2015 The Rust Project Developers. See the COPYRIGHT
- src/macros.rs:3: // http://rust-lang.org/COPYRIGHT.

## memchr 2.8.3
Published expression: Unlicense OR MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/memchr/memchr-2.8.3.crate
SHA-256: cf8baf1c55e62ffcace7a9f06f4bd9cd3f0c4beb022d3b367256b91b87513d98

### LICENSE-MIT

The MIT License (MIT)

Copyright (c) 2015 Andrew Gallant

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


## proc-macro2 1.0.107
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/proc-macro2/proc-macro2-1.0.107.crate
SHA-256: 985e7ec9bb745e6ce6535b544d84d6cd6f7ad8bd711c398938ae983b91a766d9

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## quote 1.0.47
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/quote/quote-1.0.47.crate
SHA-256: 1fbf4db142a473a8d80c26bbf18454ed458bf8d26c8219c331daecfdbd079001

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## rustix 0.38.44
Published expression: Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/rustix/rustix-0.38.44.crate
SHA-256: fdb5bc1ae2baa591800df16c9ca78619bf65c0488b41b96ccec5d11220d8c154

### COPYRIGHT

Short version for non-lawyers:

`rustix` is triple-licensed under Apache 2.0 with the LLVM Exception,
Apache 2.0, and MIT terms.


Longer version:

Copyrights in the `rustix` project are retained by their contributors.
No copyright assignment is required to contribute to the `rustix`
project.

Some files include code derived from Rust's `libstd`; see the comments in
the code for details.

Except as otherwise noted (below and/or in individual files), `rustix`
is licensed under:

 - the Apache License, Version 2.0, with the LLVM Exception
   <LICENSE-Apache-2.0_WITH_LLVM-exception> or
   <http://llvm.org/foundation/relicensing/LICENSE.txt>
 - the Apache License, Version 2.0
   <LICENSE-APACHE> or
   <http://www.apache.org/licenses/LICENSE-2.0>,
 - or the MIT license
   <LICENSE-MIT> or
   <http://opensource.org/licenses/MIT>,

at your option.


### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- Cargo.toml:26:     "COPYRIGHT",
- Cargo.toml.orig:15: include = ["src", "build.rs", "Cargo.toml", "COPYRIGHT", "LICENSE*", "/*.md", "benches"]
- ORG_CODE_OF_CONDUCT.md:107:      in copyright violation or misattribution of any kind.

## serde 1.0.229
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/serde/serde-1.0.229.crate
SHA-256: 4148590afebada386688f18773da617792bf2ef03ffc1e4cbd2b1d45b023e0ba

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## serde_core 1.0.229
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/serde_core/serde_core-1.0.229.crate
SHA-256: 67dca2c9c51e58a4791a4b1ed58308b39c64224d349a935ab5039aa360942a48

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## serde_derive 1.0.229
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/serde_derive/serde_derive-1.0.229.crate
SHA-256: e7a5d71263a5a7d47b41f6b3f06ba276f10cc18b0931f1799f710578e2309348

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## serde_json 1.0.151
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/serde_json/serde_json-1.0.151.crate
SHA-256: c841b55ecdae098c80dcae9cf767f6f8a0c2cdb3416bbef72181df4d0fe73f14

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### Additional source notices

- src/lexical/mod.rs:9: // copyright Alexander Huszagh.

## sha2 0.10.9
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/sha2/sha2-0.10.9.crate
SHA-256: a7507d819769d01a365ab707794a4084392c824f54a7a6a7862f8c3d0892b283

### LICENSE-MIT

Copyright (c) 2006-2009 Graydon Hoare
Copyright (c) 2009-2013 Mozilla Foundation
Copyright (c) 2016 Artyom Pavlov

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## syn 3.0.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/syn/syn-3.0.6.crate
SHA-256: 8593e8e72159ed2257d083c7a454a85cbf854f37a0966d8d483aff8c8a3ebcee

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## tiny_http 0.12.0
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/tiny_http/tiny_http-0.12.0.crate
SHA-256: 389915df6413a2e74fb181895f933386023c71110878cd0825588928e64cdc82

### LICENSE-MIT

Copyright (c) 2014-2019 The tiny-http contributors

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


## typenum 1.20.1
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/typenum/typenum-1.20.1.crate
SHA-256: b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20

### LICENSE-MIT

The MIT License (MIT)

Copyright (c) 2014 Paho Lurie-Gregg

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


## unicode-ident 1.0.26
Published expression: (MIT OR Apache-2.0) AND Unicode-3.0
Suggested selected terms: MIT AND Unicode-3.0
Primary source: https://static.crates.io/crates/unicode-ident/unicode-ident-1.0.26.crate
SHA-256: d245f478577f809a851594d02313b640fb437e0bb33866753cff937863096954

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.


### LICENSE-UNICODE

UNICODE LICENSE V3

COPYRIGHT AND PERMISSION NOTICE

Copyright © 1991-2023 Unicode, Inc.

NOTICE TO USER: Carefully read the following legal agreement. BY
DOWNLOADING, INSTALLING, COPYING OR OTHERWISE USING DATA FILES, AND/OR
SOFTWARE, YOU UNEQUIVOCALLY ACCEPT, AND AGREE TO BE BOUND BY, ALL OF THE
TERMS AND CONDITIONS OF THIS AGREEMENT. IF YOU DO NOT AGREE, DO NOT
DOWNLOAD, INSTALL, COPY, DISTRIBUTE OR USE THE DATA FILES OR SOFTWARE.

Permission is hereby granted, free of charge, to any person obtaining a
copy of data files and any associated documentation (the "Data Files") or
software and any associated documentation (the "Software") to deal in the
Data Files or Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, and/or sell
copies of the Data Files or Software, and to permit persons to whom the
Data Files or Software are furnished to do so, provided that either (a)
this copyright and permission notice appear with all copies of the Data
Files or Software, or (b) this copyright and permission notice appear in
associated Documentation.

THE DATA FILES AND SOFTWARE ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF
THIRD PARTY RIGHTS.

IN NO EVENT SHALL THE COPYRIGHT HOLDER OR HOLDERS INCLUDED IN THIS NOTICE
BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES,
OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE DATA
FILES OR SOFTWARE.

Except as contained in this notice, the name of a copyright holder shall
not be used in advertising or otherwise to promote the sale, use or other
dealings in these Data Files or Software without prior written
authorization of the copyright holder.


## version_check 0.9.5
Published expression: MIT/Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/version_check/version_check-0.9.5.crate
SHA-256: 0b928f33d975fc6ad9f86c8f283853ad26bdd5b10b7f1542aa2fa15e2289105a

### LICENSE-MIT

The MIT License (MIT)
Copyright (c) 2017-2018 Sergio Benitez

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


## windows-link 0.2.1
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows-link/windows-link-0.2.1.crate
SHA-256: f0805222e57f7521d6a62e36fa9163bc891acd422f971defe97d64e70d0a4fe5

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows-sys 0.59.0
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows-sys/windows-sys-0.59.0.crate
SHA-256: 1e38bc4d79ed67fd075bcc251a1c39b32a1776bbe92e5bef1f0bf1f8c531853b

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


### Additional source notices

- src/Windows/Wdk/Graphics/Direct3D/mod.rs:1615: pub const DXGKMDT_OPM_SET_PROTECTION_LEVEL_ACCORDING_TO_CSS_DVD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x39ce333e_4cc0_44ae_bfcc_da50b5f82e72);
- src/Windows/Win32/Devices/DeviceAndDriverInstallation/mod.rs:1424: pub const GUID_BUS_TYPE_SD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xe700cc04_4036_4e89_9579_89ebf45f00cd);
- src/Windows/Win32/Devices/DeviceAndDriverInstallation/mod.rs:1485: pub const GUID_DEVCLASS_LEGACYDRIVER: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8ecc055d_047f_11d1_a537_0000f8753ed1);
- src/Windows/Win32/Devices/PortableDevices/mod.rs:245: pub const NAME_GenericObj_Copyright: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Devices/PortableDevices/mod.rs:1150: pub const WPD_MEDIA_COPYRIGHT: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x2ed8ba05_0ad3_42dc_b0d0_bc95ac396ac8), pid: 4 };
- src/Windows/Win32/Devices/Properties/mod.rs:39: pub const DEVPKEY_DeviceContainer_FriendlyName: DEVPROPKEY = DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 12288 };
- src/Windows/Win32/Devices/Properties/mod.rs:60: pub const DEVPKEY_DeviceContainer_Manufacturer: DEVPROPKEY = DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8192 };
- src/Windows/Win32/Devices/Properties/mod.rs:64: pub const DEVPKEY_DeviceContainer_ModelName: DEVPROPKEY = DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8194 };
- src/Windows/Win32/Devices/Properties/mod.rs:65: pub const DEVPKEY_DeviceContainer_ModelNumber: DEVPROPKEY = DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8195 };
- src/Windows/Win32/Devices/Sensors/mod.rs:213: pub const SENSOR_DATA_TYPE_ATMOSPHERIC_PRESSURE_BAR: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 4 };
- src/Windows/Win32/Devices/Sensors/mod.rs:306: pub const SENSOR_DATA_TYPE_ENVIRONMENTAL_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4);
- src/Windows/Win32/Devices/Sensors/mod.rs:391: pub const SENSOR_DATA_TYPE_RELATIVE_HUMIDITY_PERCENT: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 3 };
- src/Windows/Win32/Devices/Sensors/mod.rs:428: pub const SENSOR_DATA_TYPE_TEMPERATURE_CELSIUS: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 2 };
- src/Windows/Win32/Devices/Sensors/mod.rs:448: pub const SENSOR_DATA_TYPE_WIND_DIRECTION_DEGREES_ANTICLOCKWISE: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 5 };
- src/Windows/Win32/Devices/Sensors/mod.rs:450: pub const SENSOR_DATA_TYPE_WIND_SPEED_METERS_PER_SECOND: super::super::UI::Shell::PropertiesSystem::PROPERTYKEY = super::super::UI::Shell::PropertiesSystem::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 6 };
- src/Windows/Win32/Devices/Sensors/mod.rs:521: pub const SENSOR_TYPE_ACCELEROMETER_2D: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xb2c517a8_f6b5_4ba6_a423_5df560b4cc07);
- src/Windows/Win32/Devices/Sensors/mod.rs:532: pub const SENSOR_TYPE_COMPASS_2D: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x15655cc0_997a_4d30_84db_57caba3648bb);
- src/Windows/Win32/Globalization/mod.rs:3617: pub const U_COPYRIGHT_STRING_LENGTH: u32 = 128u32;
- src/Windows/Win32/Globalization/mod.rs:4650:     pub pszCopyright: windows_sys::core::PWSTR,
- src/Windows/Win32/Graphics/GdiPlus/mod.rs:1262: pub const PropertyTagCopyright: u32 = 33432u32;
- src/Windows/Win32/Graphics/GdiPlus/mod.rs:1443: pub const PropertyTagThumbnailCopyRight: u32 = 20539u32;
- src/Windows/Win32/Media/Audio/mod.rs:183: pub const ACMDRIVERDETAILS_COPYRIGHT_CHARS: u32 = 80u32;
- src/Windows/Win32/Media/Audio/mod.rs:875:     pub szCopyright: [i8; 80],
- src/Windows/Win32/Media/Audio/mod.rs:896:     pub szCopyright: [u16; 80],
- src/Windows/Win32/Media/KernelStreaming/mod.rs:1186: pub const KS_DVD_COPYRIGHTED: u32 = 64u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:1187: pub const KS_DVD_COPYRIGHT_MASK: u32 = 64u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:1188: pub const KS_DVD_NOT_COPYRIGHTED: u32 = 0u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:2015:     pub fCopyrighted: super::super::Foundation::BOOL,
- src/Windows/Win32/Media/KernelStreaming/mod.rs:3170: pub const KSNODETYPE_TELEPHONY_BIDI: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x686d7cc0_d903_4258_b443_3a3d3580741c);
- src/Windows/Win32/Media/KernelStreaming/mod.rs:3185: pub const KSNODETYPE_VOLUME: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x3a5acc00_c557_11d0_8a2b_00a0c9255ac1);
- src/Windows/Win32/Media/Multimedia/mod.rs:197: pub const ACM_MPEG_COPYRIGHT: u32 = 2u32;
- src/Windows/Win32/Media/Multimedia/mod.rs:227: pub const AVIFILEINFO_COPYRIGHTED: u32 = 131072u32;
- src/Windows/Win32/Media/Multimedia/mod.rs:1288: pub const MCI_INFO_COPYRIGHT: i32 = 8192i32;
- src/Windows/Win32/Media/Multimedia/mod.rs:1401: pub const MCI_SEQ_STATUS_COPYRIGHT: i32 = 16396i32;
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:383: pub const g_wszWMCopyright: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:384: pub const g_wszWMCopyrightURL: windows_sys::core::PCWSTR = windows_sys::core::w!("CopyrightURL");
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:472: pub const g_wszWMProviderCopyright: windows_sys::core::PCWSTR = windows_sys::core::w!("WM/ProviderCopyright");
- src/Windows/Win32/NetworkManagement/NetManagement/mod.rs:2495:     pub acc0_resource_name: windows_sys::core::PWSTR,
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:362: pub const FWPM_CONDITION_ARRIVAL_INTERFACE_INDEX: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xcc088db3_1792_4a71_b0f9_037d21cd828b);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:579: pub const FWPM_LAYER_INBOUND_ICMP_ERROR_V6_DISCARD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xa6e7ccc0_08fb_468d_a472_9771d5595e09);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:614: pub const FWPM_LAYER_OUTBOUND_IPPACKET_V6_DISCARD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x9513d7c4_a934_49dc_91a7_6ccb80cc02e3);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:714: pub const FWPM_SUBLAYER_UNIVERSAL: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xeebecc03_ced4_4380_819a_2734397b2b74);
- src/Windows/Win32/Security/Cryptography/Certificates/mod.rs:1546: pub const wszCMM_PROP_COPYRIGHT: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Storage/FileSystem/mod.rs:1166: pub const PARTITION_SBL_CACHE_SSD_RESERVED_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xdcc0c7c1_55ad_4f17_9d43_4bc776e0117e);
- src/Windows/Win32/Storage/Nvme/mod.rs:10: pub const GUID_OCP_DEVICE_LATENCY_MONITOR: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8cc07a92_84d0_9c6c_7043_e6d4585ed485);
- src/Windows/Win32/Storage/Nvme/mod.rs:11: pub const GUID_OCP_DEVICE_LATENCY_MONITORGuid: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8cc07a92_84d0_9c6c_7043_e6d4585ed485);
- src/Windows/Win32/Storage/Packaging/Appx/mod.rs:304: pub const AppxPackageEditor: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xf004f2ca_aebc_4b0d_bf58_e516d5bcc0ab);
- src/Windows/Win32/System/Com/StructuredStorage/mod.rs:233: pub const PIDMSI_COPYRIGHT: i32 = 11i32;
- src/Windows/Win32/System/GroupPolicy/mod.rs:281: pub const GPMSearchCriteria: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x17aaca26_5ce0_44fa_8cc0_5259e6483566);
- src/Windows/Win32/System/Ioctl/mod.rs:3110:     pub CopyrightInfo: [u16; 34],
- src/Windows/Win32/System/RemoteDesktop/mod.rs:248: pub const RDCLIENT_BITMAP_RENDER_SERVICE: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xe4cc08cb_942e_4b19_8504_bd5a89a747f5);
- src/Windows/Win32/System/SystemServices/mod.rs:650: pub const GUID_PROCESSOR_PARKING_PERF_STATE: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x447235c7_6a8d_4cc0_8e24_9eaf70b96e2b);
- src/Windows/Win32/System/SystemServices/mod.rs:651: pub const GUID_PROCESSOR_PARKING_PERF_STATE_1: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x447235c7_6a8d_4cc0_8e24_9eaf70b96e2c);
- src/Windows/Win32/System/SystemServices/mod.rs:656: pub const GUID_PROCESSOR_PERF_BOOST_POLICY: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x45bcc044_d885_43e2_8605_ee0ec6e96b59);
- src/Windows/Win32/UI/Accessibility/mod.rs:233: pub const AppBar_Control_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x6114908d_cc02_4d37_875b_b530c7139554);
- src/Windows/Win32/UI/Accessibility/mod.rs:484: pub const LegacyIAccessible_Pattern_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x54cc0a9f_3395_48af_ba8d_73f85690f3e0);
- src/Windows/Win32/UI/Accessibility/mod.rs:940: pub const Text_MarginLeading_Attribute_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x9e9242d0_5ed0_4900_8e8a_eecc03835afc);
- src/Windows/Win32/UI/Controls/mod.rs:3398: pub const TMT_COPYRIGHT: THEME_PROPERTY_SYMBOL_ID = 605u32;
- src/Windows/Win32/UI/Input/Ime/mod.rs:1192:     pub szCopyright: [i8; 128],
- src/Windows/Win32/UI/Shell/mod.rs:2208: pub const FOLDERTYPEID_StorageProviderPictures: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x71d642a9_f2b1_42cd_ad92_eb9300c7cc0a);
- src/Windows/Win32/UI/Shell/mod.rs:3675: pub const SID_SMenuBandChild: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xed9cc020_08b9_11d1_9823_00c04fd91972);
- src/Windows/Win32/UI/TextServices/mod.rs:467: pub const TSATTRID_Font_Style_Position: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x15cd26ab_f2fb_4062_b5a6_9a49e1a5cc0b);

## windows-sys 0.61.2
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows-sys/windows-sys-0.61.2.crate
SHA-256: ae137229bcbd6cdf0f7b80a31df61766145077ddf49416a728b02cb3921ff3fc

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


### Additional source notices

- src/Windows/Wdk/Graphics/Direct3D/mod.rs:10375: pub const DXGKMDT_OPM_SET_PROTECTION_LEVEL_ACCORDING_TO_CSS_DVD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x39ce333e_4cc0_44ae_bfcc_da50b5f82e72);
- src/Windows/Win32/Devices/DeviceAndDriverInstallation/mod.rs:1990: pub const GUID_BUS_TYPE_SD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xe700cc04_4036_4e89_9579_89ebf45f00cd);
- src/Windows/Win32/Devices/DeviceAndDriverInstallation/mod.rs:2051: pub const GUID_DEVCLASS_LEGACYDRIVER: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8ecc055d_047f_11d1_a537_0000f8753ed1);
- src/Windows/Win32/Devices/Dvd/mod.rs:175: pub const DVD_COPYRIGHTED: u32 = 64u32;
- src/Windows/Win32/Devices/Dvd/mod.rs:178: pub struct DVD_COPYRIGHT_DESCRIPTOR {
- src/Windows/Win32/Devices/Dvd/mod.rs:179:     pub CopyrightProtectionType: u8,
- src/Windows/Win32/Devices/Dvd/mod.rs:185: pub struct DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR {
- src/Windows/Win32/Devices/Dvd/mod.rs:186:     pub Anonymous: DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0,
- src/Windows/Win32/Devices/Dvd/mod.rs:189: impl Default for DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR {
- src/Windows/Win32/Devices/Dvd/mod.rs:196: pub union DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0 {
- src/Windows/Win32/Devices/Dvd/mod.rs:197:     pub Dvdrom: DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_0,
- src/Windows/Win32/Devices/Dvd/mod.rs:198:     pub DvdRecordable_Version1: DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_1,
- src/Windows/Win32/Devices/Dvd/mod.rs:199:     pub Dvdram: DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_2,
- src/Windows/Win32/Devices/Dvd/mod.rs:200:     pub DvdRecordable: DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_3,
- src/Windows/Win32/Devices/Dvd/mod.rs:203: impl Default for DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0 {
- src/Windows/Win32/Devices/Dvd/mod.rs:210: pub struct DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_1 {
- src/Windows/Win32/Devices/Dvd/mod.rs:215: pub struct DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_3 {
- src/Windows/Win32/Devices/Dvd/mod.rs:220: pub struct DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_2 {
- src/Windows/Win32/Devices/Dvd/mod.rs:225: pub struct DVD_COPYRIGHT_MANAGEMENT_DESCRIPTOR_0_0 {
- src/Windows/Win32/Devices/Dvd/mod.rs:228: pub const DVD_COPYRIGHT_MASK: u32 = 64u32;
- src/Windows/Win32/Devices/Dvd/mod.rs:506: pub const DVD_NOT_COPYRIGHTED: u32 = 0u32;
- src/Windows/Win32/Devices/Dvd/mod.rs:664: pub const DvdCopyrightDescriptor: DVD_STRUCTURE_FORMAT = 1i32;
- src/Windows/Win32/Devices/PortableDevices/mod.rs:247: pub const NAME_GenericObj_Copyright: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Devices/PortableDevices/mod.rs:924: pub const WPD_MEDIA_COPYRIGHT: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x2ed8ba05_0ad3_42dc_b0d0_bc95ac396ac8), pid: 4 };
- src/Windows/Win32/Devices/Properties/mod.rs:39: pub const DEVPKEY_DeviceContainer_FriendlyName: super::super::Foundation::DEVPROPKEY = super::super::Foundation::DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 12288 };
- src/Windows/Win32/Devices/Properties/mod.rs:60: pub const DEVPKEY_DeviceContainer_Manufacturer: super::super::Foundation::DEVPROPKEY = super::super::Foundation::DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8192 };
- src/Windows/Win32/Devices/Properties/mod.rs:64: pub const DEVPKEY_DeviceContainer_ModelName: super::super::Foundation::DEVPROPKEY = super::super::Foundation::DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8194 };
- src/Windows/Win32/Devices/Properties/mod.rs:65: pub const DEVPKEY_DeviceContainer_ModelNumber: super::super::Foundation::DEVPROPKEY = super::super::Foundation::DEVPROPKEY { fmtid: windows_sys::core::GUID::from_u128(0x656a3bb3_ecc0_43fd_8477_4ae0404a96cd), pid: 8195 };
- src/Windows/Win32/Devices/Sensors/mod.rs:272: pub const SENSOR_DATA_TYPE_ATMOSPHERIC_PRESSURE_BAR: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 4 };
- src/Windows/Win32/Devices/Sensors/mod.rs:321: pub const SENSOR_DATA_TYPE_ENVIRONMENTAL_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4);
- src/Windows/Win32/Devices/Sensors/mod.rs:366: pub const SENSOR_DATA_TYPE_RELATIVE_HUMIDITY_PERCENT: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 3 };
- src/Windows/Win32/Devices/Sensors/mod.rs:385: pub const SENSOR_DATA_TYPE_TEMPERATURE_CELSIUS: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 2 };
- src/Windows/Win32/Devices/Sensors/mod.rs:395: pub const SENSOR_DATA_TYPE_WIND_DIRECTION_DEGREES_ANTICLOCKWISE: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 5 };
- src/Windows/Win32/Devices/Sensors/mod.rs:396: pub const SENSOR_DATA_TYPE_WIND_SPEED_METERS_PER_SECOND: super::super::Foundation::PROPERTYKEY = super::super::Foundation::PROPERTYKEY { fmtid: windows_sys::core::GUID::from_u128(0x8b0aa2f1_2d57_42ee_8cc0_4d27622b46c4), pid: 6 };
- src/Windows/Win32/Devices/Sensors/mod.rs:454: pub const SENSOR_TYPE_ACCELEROMETER_2D: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xb2c517a8_f6b5_4ba6_a423_5df560b4cc07);
- src/Windows/Win32/Devices/Sensors/mod.rs:465: pub const SENSOR_TYPE_COMPASS_2D: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x15655cc0_997a_4d30_84db_57caba3648bb);
- src/Windows/Win32/Globalization/mod.rs:2071:     pub pszCopyright: windows_sys::core::PWSTR,
- src/Windows/Win32/Globalization/mod.rs:4615: pub const U_COPYRIGHT_STRING_LENGTH: u32 = 128u32;
- src/Windows/Win32/Graphics/GdiPlus/mod.rs:1896: pub const PropertyTagCopyright: u32 = 33432u32;
- src/Windows/Win32/Graphics/GdiPlus/mod.rs:2077: pub const PropertyTagThumbnailCopyRight: u32 = 20539u32;
- src/Windows/Win32/Media/Audio/mod.rs:200:     pub szCopyright: [i8; 80],
- src/Windows/Win32/Media/Audio/mod.rs:227:     pub szCopyright: [u16; 80],
- src/Windows/Win32/Media/Audio/mod.rs:237: pub const ACMDRIVERDETAILS_COPYRIGHT_CHARS: u32 = 80u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:543:     pub fCopyrighted: windows_sys::core::BOOL,
- src/Windows/Win32/Media/KernelStreaming/mod.rs:2363: pub const KSNODETYPE_TELEPHONY_BIDI: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x686d7cc0_d903_4258_b443_3a3d3580741c);
- src/Windows/Win32/Media/KernelStreaming/mod.rs:2378: pub const KSNODETYPE_VOLUME: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x3a5acc00_c557_11d0_8a2b_00a0c9255ac1);
- src/Windows/Win32/Media/KernelStreaming/mod.rs:5334: pub const KS_DVD_COPYRIGHTED: u32 = 64u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:5335: pub const KS_DVD_COPYRIGHT_MASK: u32 = 64u32;
- src/Windows/Win32/Media/KernelStreaming/mod.rs:5336: pub const KS_DVD_NOT_COPYRIGHTED: u32 = 0u32;
- src/Windows/Win32/Media/Multimedia/mod.rs:197: pub const ACM_MPEG_COPYRIGHT: u32 = 2u32;
- src/Windows/Win32/Media/Multimedia/mod.rs:335: pub const AVIFILEINFO_COPYRIGHTED: u32 = 131072u32;
- src/Windows/Win32/Media/Multimedia/mod.rs:2718: pub const MCI_INFO_COPYRIGHT: i32 = 8192i32;
- src/Windows/Win32/Media/Multimedia/mod.rs:3084: pub const MCI_SEQ_STATUS_COPYRIGHT: i32 = 16396i32;
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:859: pub const g_wszWMCopyright: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:860: pub const g_wszWMCopyrightURL: windows_sys::core::PCWSTR = windows_sys::core::w!("CopyrightURL");
- src/Windows/Win32/Media/WindowsMediaFormat/mod.rs:948: pub const g_wszWMProviderCopyright: windows_sys::core::PCWSTR = windows_sys::core::w!("WM/ProviderCopyright");
- src/Windows/Win32/NetworkManagement/NetManagement/mod.rs:212:     pub acc0_resource_name: windows_sys::core::PWSTR,
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:460: pub const FWPM_CONDITION_ARRIVAL_INTERFACE_INDEX: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xcc088db3_1792_4a71_b0f9_037d21cd828b);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:885: pub const FWPM_LAYER_INBOUND_ICMP_ERROR_V6_DISCARD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xa6e7ccc0_08fb_468d_a472_9771d5595e09);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:920: pub const FWPM_LAYER_OUTBOUND_IPPACKET_V6_DISCARD: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x9513d7c4_a934_49dc_91a7_6ccb80cc02e3);
- src/Windows/Win32/NetworkManagement/WindowsFilteringPlatform/mod.rs:2233: pub const FWPM_SUBLAYER_UNIVERSAL: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xeebecc03_ced4_4380_819a_2734397b2b74);
- src/Windows/Win32/Security/Cryptography/Certificates/mod.rs:1789: pub const wszCMM_PROP_COPYRIGHT: windows_sys::core::PCWSTR = windows_sys::core::w!("Copyright");
- src/Windows/Win32/Storage/FileSystem/mod.rs:3330: pub const PARTITION_SBL_CACHE_SSD_RESERVED_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xdcc0c7c1_55ad_4f17_9d43_4bc776e0117e);
- src/Windows/Win32/Storage/Nvme/mod.rs:76: pub const GUID_OCP_DEVICE_LATENCY_MONITOR: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8cc07a92_84d0_9c6c_7043_e6d4585ed485);
- src/Windows/Win32/Storage/Nvme/mod.rs:77: pub const GUID_OCP_DEVICE_LATENCY_MONITORGuid: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x8cc07a92_84d0_9c6c_7043_e6d4585ed485);
- src/Windows/Win32/Storage/Packaging/Appx/mod.rs:256: pub const AppxPackageEditor: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xf004f2ca_aebc_4b0d_bf58_e516d5bcc0ab);
- src/Windows/Win32/System/Com/StructuredStorage/mod.rs:516: pub const PIDMSI_COPYRIGHT: i32 = 11i32;
- src/Windows/Win32/System/GroupPolicy/mod.rs:101: pub const GPMSearchCriteria: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x17aaca26_5ce0_44fa_8cc0_5259e6483566);
- src/Windows/Win32/System/Ioctl/mod.rs:2155:     pub CopyrightInfo: [u16; 34],
- src/Windows/Win32/System/RemoteDesktop/mod.rs:358: pub const RDCLIENT_BITMAP_RENDER_SERVICE: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xe4cc08cb_942e_4b19_8504_bd5a89a747f5);
- src/Windows/Win32/System/SystemServices/mod.rs:812: pub const GUID_PROCESSOR_PARKING_PERF_STATE: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x447235c7_6a8d_4cc0_8e24_9eaf70b96e2b);
- src/Windows/Win32/System/SystemServices/mod.rs:813: pub const GUID_PROCESSOR_PARKING_PERF_STATE_1: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x447235c7_6a8d_4cc0_8e24_9eaf70b96e2c);
- src/Windows/Win32/System/SystemServices/mod.rs:818: pub const GUID_PROCESSOR_PERF_BOOST_POLICY: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x45bcc044_d885_43e2_8605_ee0ec6e96b59);
- src/Windows/Win32/UI/Accessibility/mod.rs:247: pub const AppBar_Control_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x6114908d_cc02_4d37_875b_b530c7139554);
- src/Windows/Win32/UI/Accessibility/mod.rs:577: pub const LegacyIAccessible_Pattern_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x54cc0a9f_3395_48af_ba8d_73f85690f3e0);
- src/Windows/Win32/UI/Accessibility/mod.rs:1168: pub const Text_MarginLeading_Attribute_GUID: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x9e9242d0_5ed0_4900_8e8a_eecc03835afc);
- src/Windows/Win32/UI/Controls/mod.rs:6798: pub const TMT_COPYRIGHT: THEME_PROPERTY_SYMBOL_ID = 605u32;
- src/Windows/Win32/UI/Input/Ime/mod.rs:899:     pub szCopyright: [i8; 128],
- src/Windows/Win32/UI/Shell/mod.rs:3187: pub const FOLDERTYPEID_StorageProviderPictures: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x71d642a9_f2b1_42cd_ad92_eb9300c7cc0a);
- src/Windows/Win32/UI/Shell/mod.rs:6227: pub const SID_SMenuBandChild: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0xed9cc020_08b9_11d1_9823_00c04fd91972);
- src/Windows/Win32/UI/TextServices/mod.rs:659: pub const TSATTRID_Font_Style_Position: windows_sys::core::GUID = windows_sys::core::GUID::from_u128(0x15cd26ab_f2fb_4062_b5a6_9a49e1a5cc0b);

## windows-targets 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows-targets/windows-targets-0.52.6.crate
SHA-256: 9b724f72796e036ab90c1021d4780d4d3d648aca59e491e6b98e725b84e99973

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_aarch64_gnullvm 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_aarch64_gnullvm/windows_aarch64_gnullvm-0.52.6.crate
SHA-256: 32a4622180e7a0ec044bb555404c800bc9fd9ec262ec147edd5989ccd0c02cd3

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_aarch64_msvc 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_aarch64_msvc/windows_aarch64_msvc-0.52.6.crate
SHA-256: 09ec2a7bb152e2252b53fa7803150007879548bc709c039df7627cabbd05d469

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_i686_gnu 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_i686_gnu/windows_i686_gnu-0.52.6.crate
SHA-256: 8e9b5ad5ab802e97eb8e295ac6720e509ee4c243f69d781394014ebfe8bbfa0b

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_i686_gnullvm 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_i686_gnullvm/windows_i686_gnullvm-0.52.6.crate
SHA-256: 0eee52d38c090b3caa76c563b86c3a4bd71ef1a819287c19d586d7334ae8ed66

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_i686_msvc 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_i686_msvc/windows_i686_msvc-0.52.6.crate
SHA-256: 240948bc05c5e7c6dabba28bf89d89ffce3e303022809e73deaefe4f6ec56c66

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_x86_64_gnu 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_x86_64_gnu/windows_x86_64_gnu-0.52.6.crate
SHA-256: 147a5c80aabfbf0c7d901cb5895d1de30ef2907eb21fbbab29ca94c5b08b1a78

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_x86_64_gnullvm 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_x86_64_gnullvm/windows_x86_64_gnullvm-0.52.6.crate
SHA-256: 24d5b23dc417412679681396f2b49f3de8c1473deb516bd34410872eff51ed0d

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## windows_x86_64_msvc 0.52.6
Published expression: MIT OR Apache-2.0
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/windows_x86_64_msvc/windows_x86_64_msvc-0.52.6.crate
SHA-256: 589f6da84c646204747d1270a2a5661ea66ed1cced2631d546fdfb155959f9ec

### license-mit

    MIT License

    Copyright (c) Microsoft Corporation.

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE


## zmij 1.0.23
Published expression: MIT
Suggested selected terms: MIT
Primary source: https://static.crates.io/crates/zmij/zmij-1.0.23.crate
SHA-256: 29666d0abbfad1e3dc4dcf6144730dd3a3ab225bbbdac83319345b1b44ccfc1b

### LICENSE-MIT

Permission is hereby granted, free of charge, to any
person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the
Software without restriction, including without
limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software
is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice
shall be included in all copies or substantial portions
of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

