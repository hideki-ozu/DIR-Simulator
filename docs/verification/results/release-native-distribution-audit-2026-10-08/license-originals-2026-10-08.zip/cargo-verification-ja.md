# Cargo ライセンス照合（固定版）

対象: hideki-ozu/DIR-Simulator @ d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b

公式 crates.io の配布アーカイブ42件を取得し、全件で Cargo.lock 記載SHA-256と一致。全件のlicense本文を確認。package code実行・repo変更はなし。

| package | version | 宣言license | 本文 |
|---|---|---|---|
| ascii | 1.1.0 | Apache-2.0 OR MIT | 確認済 |
| bitflags | 2.13.2 | MIT OR Apache-2.0 | 確認済 |
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | 確認済 |
| cfg-if | 1.0.5 | MIT OR Apache-2.0 | 確認済 |
| chunked_transfer | 1.5.0 | MIT OR Apache-2.0 | 確認済 |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | 確認済 |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | 確認済 |
| digest | 0.10.7 | MIT OR Apache-2.0 | 確認済 |
| errno | 0.3.14 | MIT OR Apache-2.0 | 確認済 |
| generic-array | 0.14.7 | MIT | 確認済 |
| httpdate | 1.0.3 | MIT OR Apache-2.0 | 確認済 |
| itoa | 1.0.18 | MIT OR Apache-2.0 | 確認済 |
| libc | 0.2.189 | MIT OR Apache-2.0 | 確認済 |
| linux-raw-sys | 0.4.15 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | 確認済 |
| log | 0.4.34 | MIT OR Apache-2.0 | 確認済 |
| memchr | 2.8.3 | Unlicense OR MIT | 確認済 |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | 確認済 |
| quote | 1.0.47 | MIT OR Apache-2.0 | 確認済 |
| rustix | 0.38.44 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | 確認済 |
| serde | 1.0.229 | MIT OR Apache-2.0 | 確認済 |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | 確認済 |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | 確認済 |
| serde_json | 1.0.151 | MIT OR Apache-2.0 | 確認済 |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | 確認済 |
| syn | 3.0.6 | MIT OR Apache-2.0 | 確認済 |
| tiny_http | 0.12.0 | MIT OR Apache-2.0 | 確認済 |
| typenum | 1.20.1 | MIT OR Apache-2.0 | 確認済 |
| unicode-ident | 1.0.26 | (MIT OR Apache-2.0) AND Unicode-3.0 | 確認済 |
| version_check | 0.9.5 | MIT/Apache-2.0 | 確認済 |
| windows-link | 0.2.1 | MIT OR Apache-2.0 | 確認済 |
| windows-sys | 0.59.0 | MIT OR Apache-2.0 | 確認済 |
| windows-sys | 0.61.2 | MIT OR Apache-2.0 | 確認済 |
| windows-targets | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_aarch64_gnullvm | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_aarch64_msvc | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_i686_gnu | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_i686_gnullvm | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_i686_msvc | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_x86_64_gnu | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_x86_64_gnullvm | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| windows_x86_64_msvc | 0.52.6 | MIT OR Apache-2.0 | 確認済 |
| zmij | 1.0.23 | MIT | 確認済 |

## 配布への反映
- 42件すべてMIT選択肢あり。ただし unicode-ident 1.0.26 は Unicode-3.0 を追加適用。MIT OR Apache-2.0と同列に単純化しない。
- 各版の原本MIT本文・copyrightをまとめて同梱可能。選択しないApache条項を必須と断定しない。
- rustix/linux-raw-sysは独立COPYRIGHTも保存。rustixにはCC0-1.0由来vdso.rsあり。
- serde_jsonのlexical部分のAlexander Huszagh notice、errno/log/asciiのRust Project noticeを落とさない。chunked_transferのSean McArthur noticeはテストソース内。
- version_checkの旧表記MIT/Apache-2.0は同梱READMEの選択許諾に基づきMIT OR Apache-2.0へ正規化可能。
- upstream MIT本文に氏名・年がないcrateは勝手に創作しない。
- Lockfile全件は実行バイナリ含有全件と同義ではない。Windows限定・build/proc-macro/testを実配布物別に区分する必要。
- 完成配布zip/バイナリへのnotice同梱・ソース公開条件の履行は別途確認。今回の結果だけで適法保証や違反断定をしない。

## 一次出典
各行の正確versionアーカイブ: https://static.crates.io/crates/{name}/{name}-{version}.crate。展開せずtarfileで読取り、Cargo.toml、license類、source noticeを採取。全42件の実URL/ハッシュ/本文はJSONに格納。

## Cargo外
- main treeにpackage.json/npm lockなし。viewer/editor JSはローカル自前コードへの読込のみ（検査範囲で外部runtime依存なし）。
- テストとブラウザ検証はPlaywrightをrequireするがversion固定なし。実利用version、ブラウザ配布の有無は未確認。
- MkDocs1.6.1とガイド同梱資産は別報告。Python推移依存の環境lockなし。