# v1.1.4候補: 配布範囲・台帳・再現メタデータの不足

確認日: 2026-10-08 UTC。対象は PR #37 の**マージコミット d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b**。可動mainやPR先端a8bd540ではない。[PR #37](https://github.com/hideki-ozu/DIR-Simulator/pull/37) は merged=true、merge_commit_sha一致をGitHub APIで確認した。

## 結論

候補ソースに配布条件・確認手順は存在するが、規定の採用物台帳が存在しない。第三者表示の収集、配布物別の対象確定、実在台帳へのmetadata参照が未完了。候補ソースの検査を正式v1.1.4製品アーカイブの合格とは扱えない。正式製品アーカイブは今回生成・実行・公開していない。

## 版の識別

- READMEの文書版1.1.7、予定GitHub公開版v1.1.4、Cargoパッケージ版0.1.0は別の識別子。README L31はCargo版をGitHub版と分けて管理すると明記しており、0.1.0を単純な更新漏れとは判定しない
- README L4の main @ 2f1e60b はPR作成基準として記載されたもの。今回の監査対象を示す完全SHAへ読み替えない。配布記録には完全マージSHAを別途固定する
- runtime_versionはCARGO_PKG_VERSION由来なので0.1.0を返す実装。v1.1.4との対応は配布側の記録、git_commit、Cargo.lock hash、binary hashで識別する必要がある

## 配布物を区別する

1. **候補ソースアーカイブ**: 取得済み candidate-d7cb386-source.zip を読み、主要16ファイルが固定SHAのGitHub blobと一致することを独立確認。Cargo.lock、プロジェクトLICENSE三点、ソース・例・文書・検証記録を含む。全ファイルの一致証明は別のsource監査結果に委ねる。依存crateアーカイブを同梱したバイナリ配布ではない
2. **正式製品配布**: 固定候補から作った正式v1.1.4 archiveを本調査では確認していない。固定treeのworkflowはguide用2本のみで、製品のrelease/package workflowはない。品質方針は配布archiveの照合を要求するが、製品の出荷ファイル一覧・target別依存区分・製品archive hashはまだ確定できない
3. **公開guide**: docs/guideをMkDocsでbuild/guideへ生成し、main push後のチェック成功時にそのディレクトリだけをPagesへ配布。開発環境・guide-evidenceは配布対象外。生成HTML/CSS/JS/font/search資産は配布対象。can-guide-inputs.zip / canfd-guide-inputs.zipは実習入力で、製品バイナリやサイト全体の配布ZIPではない

results/manifest.jsonはシミュレーション出力5ファイルの整合性用である。manifest.metadata_refはresults.json#/metadata固定で、自身を除く4ファイルのhashを列挙する。製品配布アーカイブの全ファイルinventoryやSBOMの代わりにはならない。

## 確認した不足

- **採用物台帳がない**: GitHub recursive tree 4,224項目、truncated=falseでdocs/third-party配下0件。品質・配布方針§2が要求する docs/third-party/採用物台帳.md がない。名前、版、用途、取得URL・日、ソースhash、SPDX式、著作者、改変有無、同梱文書、確認者・日、判定を一採用物一行で記す必要がある。Cargo直接・推移依存と配布一覧の突合も規定されている
- **第三者通知の配布対応がない**: tree上の独立license集合はプロジェクト三点とguideの既存7系統。Cargo42件の原文照合は先行監査で完了したが、そのnoticeを正式配布集合へ対応付けた台帳・同梱物は未確定。guideのPopper 2.11.8 MIT未掲示は先行の実公開資産監査に従う。本調査で追加の法的適否を断定しない
- **台帳欠落をmetadataが埋め合わせない**: build.rs L92–98は台帳不存在時adoption_ledger_sha256をnot-presentにし、adoption_ledger_versionにはGit SHAを入れる。SHAが存在しても、そのrevisionに台帳がない以上、検証規定DIR-TEST-0087の「配布に使用した台帳版へ到達」は満たさない
- **identifiedの判定は台帳完備の証明ではない**: metadata/reproduction.rs L300–312はbuild値のunknown有無だけでreproduction_conditionsを判定する。not-presentは除外されているので、ほかの値が既知なら台帳欠落のままidentifiedとなり得る。これはソースの静的読解で、候補バイナリの新規実行結果ではない
- **guide環境の完全lockがない**: requirements-guide.txtはmkdocs==1.6.1のみ。workflowはPython 3.11を指定しpip installするが推移Python依存の版/hash固定・freezeを生成していない。guideリンク検査はリンク・拡張子・漏洩を検査するもので、第三者ライセンスの網羅確認ではない
- **source ZIP単独の来歴が欠け得る**: build.rsはgit rev-parse HEADから来歴を得る。Git履歴のない隔離したsource展開ディレクトリではgit_commit/adoption_ledger_version等がunknownになり得る。展開先に別Git親がある場合も対象revisionが混ざらないよう確認が必要。今回ビルドしていない

## 次に実施すべき照合手順（未実行）

1. 製品、候補/正式source、guideを個別の配布集合として定義し、完全commit・archive SHA-256・全パス/bytes/hash inventoryを保存する。正式製品未生成を候補source取得で置き換えない
2. Cargo.lock全42件の照合資料を台帳へ反映し、採用ライセンス、追加表示、改変、source/build/proc-macro/test/target/runtimeの区分を固定する。各target/features/profileのcargo metadata --locked / cargo tree等の記録で実際の配布対応を補う。これらのコマンドは本調査では実行していない
3. guide実配布CSS/JS/font/searchごとに元パッケージ、版、hash、著作者/本文・source提供場所を対応付け、Popperを含む不足通知を補う。Python/Playwrightはビルド・検証環境と実配布の区分を維持する
4. 実在台帳の版/hashと、その台帳を含む対象commitから製品を構築し、results.metadata.adoption_ledger_version/adoption_ledger_sha256が到達可能で一致することを検査。manifest.metadata_ref・binary hash・Cargo.lock hashも同じ実行で照合する。not-present/unknownの扱いを明示する
5. DIR-TEST-0087の各行について配布集合・原文条件・判定根拠・確認者/日・未解決事項を保存する。既存acceptance記録も台帳・固定配布archive未完了を明記しているため、一般テスト成功だけで完了へ変更しない

## 根拠

- [品質・配布方針](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/docs/品質・配布方針.md) §2
- [配布照合の検証規定](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/docs/verification/cases/利用フロー・品質検証仕様書.md#dir-test-0087) L312–322
- [build.rs](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/crates/dir-simulator/build.rs#L92-L98)
- [metadata判定](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/crates/dir-simulator/src/output/metadata/reproduction.rs#L300-L312)
- [guide workflow](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/.github/workflows/guide-pages.yml)
- [guide配布の規定](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/docs/ガイド作成・統合手順.md#L21-L25)
- [既存acceptanceの未完了記録](https://github.com/hideki-ozu/DIR-Simulator/blob/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b/docs/verification/results/acceptance-2026-10-08.md#L54-L56)

照合に使用した16ファイルのGitHub応答・blob/SHA-256とPR/tree要約はdistribution-scope-evidence.jsonへ保存。本作業はread-only。リポジトリ編集、tag/Release作成、packageコード・install scriptの実行は行っていない。
