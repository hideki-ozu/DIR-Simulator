# v1.1.4候補ソースの照合

## 結論

v1.1.4候補の依存ライセンスと固定ソースは照合済みです。正式v1.1.4の製品配布archiveが未生成であることとは区別します。

対象はPR #37のmerge commit `d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b`。GitHub APIでPRのmerged状態とmerge SHAを確認し、そのcommitのSource ZIPを実取得しました。先のmain原文照合もこの同じcommitを対象にしていたため、既完了のCargo42件・ガイド第三者本文の検証結果を再利用しています。

[PR #37](https://github.com/hideki-ozu/DIR-Simulator/pull/37)  
[固定候補ソース](https://github.com/hideki-ozu/DIR-Simulator/tree/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b)  
[実取得Source ZIP](https://api.github.com/repos/hideki-ozu/DIR-Simulator/zipball/d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b)

## Source ZIPの実物確認

- 取得サイズ：16,344,474 bytes
- SHA-256：41709cb6a49df93fd900a09d1c0de0d38486ae4f11f64708bf31df54f3409db4
- CRC検査：正常
- 収録ファイル：3,465件
- 固定commitの非切詰Git treeのblob：3,465件
- 全ファイルのGit blob hashが一致し、不足・余分・不一致は0件

GitHub自動生成ZIPの圧縮byteは将来変わり得ます。固定commitと各Git blobの一致を主たる内容確認とします。

## 正式v1.1.3との差分

基準は `dd6199503913db24729f04bcca7e9e4f856fd71c` の実取得Source ZIPです。候補には2,797ファイルが追加され、105ファイルが変更、削除は0件でした。追加の2,185件は保存された検証証跡です。ファイル増加を新しい外部依存数とはみなしません。

Cargo.lockはv1.1.3とbyte単位で同一。42件すべてのname・version・checksumが公式crate照合済みの台帳データと一致します。Cargo.tomlの差分は、既存sha2 0.10をbuild-dependenciesにも加えた点です。新しいcrateやversionはありません。

証跡内に保存された3つのCargo.lockもrootのCargo.lockと一致しています。これらを別依存42件として重複計上しません。

候補sourcearchiveにvendor/node_modules/targetディレクトリや通常の実行binary・共有library・crate・fontファイルの同梱は見つかりません。内包ZIPはCAN/CAN FDの実習入力2件で、前の公開物照合で全19内部ファイルを確認済みです。ソース全体の文字列走査は来歴の完全証明ではありませんが、変更された実装・設定・frontendの範囲で新たな外部runtime JSの取り込みは確認されませんでした。Playwright参照は検証用です。

## 版番号の解釈

候補READMEは文書バージョン1.1.7、予定公開版v1.1.4と書かれ、対象基準commit欄にはPR作成時のmain `2f1e60b` が残っています。Cargo packageは意図的に0.1.0を維持し、GitHub公開版と別管理です。文書版1.1.7、GitHub候補v1.1.4、Cargo0.1.0を混同しません。候補として固定した実体はPR merge SHAです。

## 配布前の残件

依存の原文不明ではなく、採用物台帳・配布物への同梱・実物検証が残っています。具体的な規定との照合は同フォルダのdistribution-scope報告を参照してください。

- 固定候補では採用物台帳が未収録。metadataの台帳versionにGit SHAがあるだけでは足りない
- Cargo第三者原文・著作権表示・Unicode notice等を対象OS/実配布形態に対応づける
- ガイドのPopper2.11.8 MIT通知を追加し、lunr-languagesの出典を固定する
- 正式製品archiveを作る段階で、実際の同梱集合、NOTICE/ライセンス、台帳とmetadataの対応を再検査する
- 未固定のPlaywright/Python実行環境と、配布される製品依存を区別する

正式v1.1.4 Release/tagは前の確認で存在せず、今回は作成・公開していません。新規ビルドを正式配布物の代わりにして合格としたわけでもありません。これは候補ソース・依存出典の技術的照合であり、法的保証ではありません。
