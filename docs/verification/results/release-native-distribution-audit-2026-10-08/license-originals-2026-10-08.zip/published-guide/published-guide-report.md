# DIR Simulator 公開ガイド実物照合

取得期間（UTC）：2026-10-08T11:58:05.181551+00:00 〜 2026-10-08T12:01:46.474123+00:00  
対象：[公開ガイド](https://hideki-ozu.github.io/DIR-Simulator/)  
公開HTML記載のビルド日時：2026-10-08 10:57:51.494914+00:00  
比較元の固定main：`d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b`

## 結論

- 公開ガイドのMkDocs由来26資産は、公式MkDocs 1.6.1同梱物と全件バイト一致。CSS 6・CSS map 1・JS 8・JS map 1・画像2・font 8を確認した
- 既存の第三者ライセンス本文7件はすべてHTTP 200で公開され、固定mainおよび先行調査で取得した公式本文と全件バイト一致
- Popper 2.11.8は公開Bootstrap bundle内に含まれる。しかし確認したnotice集合・sources.txt・bundle/mapではPopperの著作権表示とMIT本文を確認できず、この不足は公開配布側にも残っていると判断する材料がある。未発見のURLまで含むサイト全体の不存在は断定しない
- MPL対象の未圧縮sourceと元のヘッダ、fontのOFL/著作権表示は実際に公開されている
- 公開ZIPリンクは実習入力2本。CAN 11件＋CAN FD 8件＝19ファイルで、全19内部ファイルも両ZIP自体も固定mainと一致。サイト全体のHTML配布ZIPやシミュレータ実行バイナリではない

## 1. 公開物のバージョンと照合範囲

入口ページは文書バージョン1.1.4、対象GitHub版v1.1.3、対象コードcommit `dd6199503913db24729f04bcca7e9e4f856fd71c` と明記する。文書1.1.4から実行バイナリv1.1.4の存在は推定しない。

HTMLナビゲーションと画像・script・stylesheet参照、CSS内font/image参照、検索workerと日本語検索設定を静的に調査した。8 HTMLページを含む58実ファイルを取得した（rootとindex.htmlの重複取得を除く）。既知のnotice URLと2件のPopper候補パスも検証した。サイトで実行したり再ビルドしたりせず、配信byteをそのまま比較している。

26資産の一致内訳：

- Bootstrap bundle 5.3.2、Bootswatch CSS 5.3.2、それぞれのsource map
- Font Awesome Free 6.5.1のCSS 4件とTTF/WOFF2 8件。fontはGitタグの別生成binaryではなく、公式npm配布物と一致する先行調査のMkDocs資産が比較対象
- lunr.js 2.3.9、日本語lunr-languages 1.12.0、TinySegmenter 0.1、検索main/worker
- MkDocs base CSS/JS、favicon、grid image

固定mainに直接存在する公開ファイル23件もGit blob hashで全件一致した。ただし、この一致は比較対象のファイルに限定され、デプロイcommitそのものを証明するものではない。

## 2. 公開済みnotice 7件

- [bootstrap-MIT.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/bootstrap-MIT.txt)：固定main・公式本文と完全一致
- [bootswatch-MIT.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/bootswatch-MIT.txt)：固定main・公式本文と完全一致
- [fontawesome-license.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/fontawesome-license.txt)：固定main・公式本文と完全一致
- [lunr-MIT.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/lunr-MIT.txt)：固定main・公式本文と完全一致
- [tinysegmenter-license.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/tinysegmenter-license.txt)：固定main・公式本文と完全一致
- [mkdocs-BSD.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/mkdocs-BSD.txt)：固定main・公式本文と完全一致
- [lunr-languages-MPL.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/lunr-languages-MPL.txt)：固定main・公式本文と完全一致

プロジェクト自身のLICENSE / MIT / Apache本文3件もHTTP 200で取得し、固定mainと一致した。上の7件には数えていない。

## 3. Popper 2.11.8：公開notice集合でも未確認

[公開Bootstrap bundle](https://hideki-ozu.github.io/DIR-Simulator/js/bootstrap.bundle.min.js) と [source map](https://hideki-ozu.github.io/DIR-Simulator/js/bootstrap.bundle.min.js.map) は公式MkDocs資産と完全一致。source mapにはPopper由来55ファイルが含まれる。先行調査では、この55 sourceが公式 @popperjs/core 2.11.8と全件一致し、npm archive integrityとBootstrap package-lockも確認している。

一方、次ではPopperの `Copyright (c) 2019 Federico Zivolo` とMIT許諾本文を確認できなかった。

- 確認済みの第三者notice 7件とプロジェクトlicense 3件
- [公開sources.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/sources.txt)
- bundleとsource map自体

`assets/licenses/popper-MIT.txt` と `assets/licenses/popper-2.11.8-MIT.txt` は取得時404。この2件だけを根拠にサイト内の全URLで不存在とは断定しない。

対応案は、先行調査で保存した公式Popper 2.11.8 MIT本文を公開notice集合へ追加し、sources.txt/配布台帳にも依存関係とversionを追記すること。今回は調査のみで、公開サイトやrepositoryは変更していない。

## 4. MPL sourceとfont notice

- [lunr.ja.js](https://hideki-ozu.github.io/DIR-Simulator/search/lunr.ja.js) と [lunr.stemmer.support.js](https://hideki-ozu.github.io/DIR-Simulator/search/lunr.stemmer.support.js) は未圧縮sourceで、公式MkDocsおよび先行調査のlunr-languages 1.12.0に一致。元の著作権/MPLヘッダを保持し、MPL-1.1全文も公開されている
- [tinyseg.js](https://hideki-ozu.github.io/DIR-Simulator/search/tinyseg.js) も一致し、TinySegmenterの著作権/BSD説明が残る
- TTF/WOFF2 8件は公式npm由来の同梱binaryと一致。[fontawesome-license.txt](https://hideki-ozu.github.io/DIR-Simulator/assets/licenses/fontawesome-license.txt) にFonticonsの著作権、Reserved Font NameとOFL-1.1全文がある。CSSはMIT、fontはOFL。取得したtheme集合にはCC-BY対象のSVG/JS icon資産を含まない
- sources.txtのlunr-languages参照はまだmaster。version 1.12.0または固定commitへの変更は再現性改善事項
- 8 HTMLページのリンク集合にはライセンス案内リンクを発見できなかった。本文は直接URLで取得できるため、入口/フッターからnotice一覧にリンクすると確認しやすい

## 5. 実際のダウンロードZIP

### can-guide-inputs.zip

[公開ZIP](https://hideki-ozu.github.io/DIR-Simulator/downloads/can-guide-inputs.zip)：3,565 bytes、11 files  
SHA-256：`f1aa61504d1c807b63d09ac75f5876e2e2ff36caa9010e0a47fbb41a3cc58e50`

- `examples/guide/can/fast.ini`
- `examples/guide/can/filter-id.ini`
- `examples/guide/can/filter-none.ini`
- `examples/guide/can/id-swap.ini`
- `examples/guide/can/id-swap.json`
- `examples/guide/can/minimal.ini`
- `examples/guide/can/minimal.json`
- `examples/guide/can/models/demo/Main.ned`
- `examples/guide/can/rx-delay0.ini`
- `examples/guide/can/rx-delay200.ini`
- `examples/guide/can/rx-delay900.ini`

### canfd-guide-inputs.zip

[公開ZIP](https://hideki-ozu.github.io/DIR-Simulator/downloads/canfd-guide-inputs.zip)：3,044 bytes、8 files  
SHA-256：`43319ed17f328514b9e2714ef6ca2f69af615b4f3cec0b1d17a9e78695f70b55`

- `examples/guide/canfd/data1.ini`
- `examples/guide/canfd/data2.ini`
- `examples/guide/canfd/data4.ini`
- `examples/guide/canfd/model.json`
- `examples/guide/canfd/models/fd/Main.ned`
- `examples/guide/canfd/workload-1.json`
- `examples/guide/canfd/workload-2.json`
- `examples/guide/canfd/workload-4.json`

両ZIPのCRC検査は正常。ZIP byteそのもの、全19内部ファイル、固定mainのexamples/guide配下に期待されるファイル集合がすべて一致した。格納内容はINI/JSON/NEDのみで、第三者JS/CSS/fontやEXE/DLLを含まない。したがって、これらの実習ZIPにMkDocs/Bootstrap等の配布noticeが入っていないことを、ガイドthemeの第三者notice欠落とは混同しない。

ZIP内にはREADME、license、version/commit manifestやchecksum manifestがない。配布自体の自己記述性は改善余地があるが、本照合が作成したmanifestは監査成果であり、公開ZIPに元から同梱されていたものではない。ZIPの対象版はリンク元文書から読み取り、byte照合結果で固定mainへの一致を確認した。

## 6. 証拠ファイルと限界

- `published-guide-report.json`：機械可読の結論、取得時刻、各notice/source/versionと照合結果
- `asset-comparisons.json`：MkDocs 26資産のSHA-256
- `all-file-comparisons.json`：取得ファイルのhashと固定mainへの比較
- `zip-inventories.json`：2 ZIP・19内部ファイル全件、CRC・集合・blob検証
- `fetch-manifest.json`：URL、HTTP status、headers、取得時刻、hash

この結果は上記取得時点のsnapshotである。Webサーバー全ファイルの一覧、未リンクURL、デプロイcommitの証明、browser実行、build時Pythonの推移依存version、Release配布物はこの範囲外。公開物の技術的な証拠照合であり、最終的な法律判断ではない。
