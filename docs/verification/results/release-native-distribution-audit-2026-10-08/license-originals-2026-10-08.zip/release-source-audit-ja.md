# 正式Releaseの実配布物照合

確認日時: 2026-10-08 11:57–11:58 UTC

## v1.1.3

[最新正式Release](https://github.com/hideki-ozu/DIR-Simulator/releases/tag/v1.1.3)は `dd6199503913db24729f04bcca7e9e4f856fd71c` を指す。GitHub APIの `releases/latest` とタグ参照を確認した。アップロードされたRelease assetは0件であり、製品バイナリZIPの添付はない。

GitHubの[自動生成Source code ZIP](https://api.github.com/repos/hideki-ozu/DIR-Simulator/zipball/v1.1.3)を実取得して内容を読んだ。ファイルサイズは1,809,297 bytes。ZIP全体のSHA-256と収録一覧は `release-source-audit.json` に記録した。自動生成ZIPの圧縮バイトは将来変わる可能性があるため、固定コミットと収録ファイル内容を主たる版根拠とする。

- Cargo.lockの外部依存は42件。先に照合したmain `d7cb3861...` の42件と、name・version・checksumが全件一致
- Cargo依存の公式本文照合結果は再利用できるが、製品実装やガイドの版が同じという意味ではない
- `LICENSE`、`LICENSE-MIT`、`LICENSE-APACHE` が収録され、プロジェクト自身のMIT OR Apache-2.0許諾と第三者資産の除外が明記されている
- `vendor`、`node_modules`、`target` の配布ディレクトリ、および通常の実行バイナリ・共有ライブラリ・crate・fontファイルは収録一覧に見つからない
- これは依存コードを取り込んだ製品バイナリ配布ではなく、非vendoredなソース配布として区分する。lockfileに名前があるだけで依存コードが配布されるとは断定できないため、Cargo42件の原文がZIP内にないこと自体を違反と判定しない
- テストのPlaywright参照は開発検証用で、Playwrightやブラウザ本体の同梱は見つからない。正確な実行環境のversionが固定されていない点は引き続き未確定

## v1.1.4

`releases/tags/v1.1.4` と `git/ref/tags/v1.1.4` は確認時点でともに404だった。存在する公開Release/tagとしては確認できず、v1.1.4製品配布archiveを実物検査して合格とすることはできない。ガイド文書の1.1.4表示は製品Release v1.1.4の存在証明ではない。

## 範囲

実取得したSource code ZIPとRelease APIメタデータの照合である。バイナリを新たにビルドして配布検査に代用していない。リポジトリ・Release・サイトは変更していない。法的適合性の保証ではない。
