# DIR Simulator 依存ライセンス照合結果

対象は hideki-ozu/DIR-Simulator の main 固定コミット d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1b です。2026年10月8日に一次配布元を照合しました。これは採用物台帳へ反映するための出典・本文の検証結果であり、法律上の適法保証ではありません。

## v1.1.4候補についての追加結論

v1.1.4候補はPR #37 merge commit d7cb3861f9ac56646ac2dbacf6f324b12f7fcb1bに固定し、Source ZIPの全3,465ファイルをGit treeと照合しました。全件一致です。先のCargo42件原文照合もこのcommitが対象で、v1.1.3からCargo.lockの変更はありません。候補ソースの照合は完了しています。正式製品archiveの同梱検査は、未生成のため未完了です。

候補では規定上必要な採用物台帳の欠落、metadataと台帳への対応、第三者noticeの配布物同梱が残件です。詳しくはcandidate-v1.1.4/の報告を参照してください。

## 公開配布物の追加照合

初回の原文照合後、2026年10月8日11:57–12:01 UTCに実公開サイトと正式Releaseを追加確認しました。初回報告中の「公開物未検査」は当時の範囲を示す記録です。現在の実配布物に関する結論は、追加報告を参照してください。

- 公開ガイドのCSS・JS・source map・font等26件は公式MkDocs1.6.1同梱物と全件バイト一致
- 公開された既存7種license原文は公式と一致し、MPL対象の非圧縮JS sourceも公開されている
- Popperを含むBootstrap bundleは公開中だが、確認した7通知とsources.txtにはPopperの著作権・MIT通知が掲載されていない。サイトの未リンクファイル全体の不存在までは断定しない
- 公開ZIP2件はサイト一式ではなく実習入力。CAN11件＋CANFD8件＝19ファイルすべてが固定mainと一致し、JS/CSS/font/製品バイナリは含まれない
- 正式latest v1.1.3はRelease asset0件。自動Source code ZIPを実取得し、Cargo42件のname/version/checksumが先の照合と一致。依存コードをvendoringしたバイナリZIPとは区別する
- v1.1.4はRelease/tagとも確認時API404。製品配布物を仮作成して検証済みとはしていない

追加結果は published-guide/ の報告と release-source-audit-ja.md / release-source-audit.json に収録しました。

## 初回の固定mainと公式原文の照合

Cargo.lock の外部依存42件は、正確なversionの公式配布アーカイブを取得し、42件すべてでSHA-256がlockfileと一致しました。各アーカイブのCargo.toml、ライセンス本文、著作権表示を確認し、追加のsource noticeも調べました。ライセンス不明としたCargo依存はありません。

全42件にMITの選択肢があります。ただし unicode-ident 1.0.26 は追加でUnicode-3.0が適用されます。rustixのCC0-1.0由来部分と、各crateに含まれる別著作権表示も台帳へ反映してください。単にプロジェクト自身のMIT/Apache本文を置くだけでは、これら第三者の表示を網羅できません。

ガイド用MkDocs 1.6.1の同梱資産と、リポジトリ内の既存7種ライセンス本文も照合しました。Bootstrap 5.3.2のbundleにはPopper 2.11.8が含まれますが、現在のライセンス集合・sources.txtにはPopperの記載がありません。追加するMIT原文を同封しています。lunr-languages 1.12.0はMPL-1.1、Font Awesomeの今回のCSSはMIT・フォントはOFL-1.1です。ガイドの詳しい照合結果で、資産単位のライセンスと残課題を確認してください。

## ファイル案内

- cargo-verification-ja.md: Cargo42件の読みやすい一覧と配布上の留意点
- cargo-verification-summary.json: 42行の台帳データ案。version、宣言式、一次URL、ハッシュ、notice条件を収録
- cargo-evidence-expanded.json: 全ライセンス原文とsource notice検出結果
- cargo-selected-notices.md: MITを選択した場合の原文notice集案。Unicode等の追加表示を含む
- cargo-special-license-review.json: rustix等7件の追加確認と固定コミット出典
- windows-license-verification.json: Windows関連12件の独立照合
- repo-js-scan.json: JS/HTML参照の調査証跡
- repository-scope.json / Cargo.lock: 調査対象の固定版と範囲
- guide関連ファイル: MkDocs同梱資産の照合結果、追加Popperライセンス、検証出典

## 未確定部分と次の確認

1. この42件はlockfileの全件です。実行バイナリにすべて入ることを意味しません。実際のOS・features・build/proc-macro/testの区分は、配布物別に確認してください。
2. 完成した配布ZIP、バイナリ、公開ガイドへのnotice同梱やソース提供条件の履行は、今回の一次出典照合とは別の確認です。Popperの指摘は固定mainの原本セットとの比較であり、公開サイトの違反を断定したものではありません。
3. Viewer/NED editorの検査範囲では、外部npm runtimeの読込は見つかりませんでした。ブラウザ検証ではPlaywrightを使用しますが、package.jsonやnpm lockはなく正確な利用versionが固定されていません。実行環境のversionとブラウザ再配布の有無は未確認です。
4. PythonはMkDocs本体1.6.1のみ固定され、推移依存の環境lockはありません。開発環境全体の確定版SBOMではありません。
5. ライセンス名を検出するツールや文字列走査だけで完全なコード来歴を証明することはできません。原文保持と配布物別確認を組み合わせてください。

## 変更していないもの

本照合ではGitHubのファイル、ブランチ、PR、公開サイトを変更していません。依存パッケージのコードやインストールスクリプトも実行していません。
