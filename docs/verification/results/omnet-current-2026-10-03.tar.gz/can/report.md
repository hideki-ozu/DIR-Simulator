# DIR / OMNeT++ CAN 実行結果比較

実行日時（UTC）: 2026-10-03T06:23:09.718235+00:00

43 / 43ケースを両エンジンで実行。共通観測項目の一致は4ケース、差異ありは39ケース。
これは同じ入力に対するモデル間比較であり、OMNeT++をDIRの正解値とする適合認証ではない。

## 比較条件

OMNeT++ 6.4 / ローカルFiCo4OMNeTの既存CANバス・ポート・仲裁・時間計算を使用。原ソースは変更せず、入力注入と観測用の外部テストモジュールを追加した。
送信時刻、ID形式・値、payload全バイト、500k/1M/333333bps、3ノード、観測期間をDIRと共通化。キュー容量（送信中を除くdrop-tail）、TX/RX処理遅延、受信フィルタ、配送遅延はテストアダプターで補った。MOB=false、誤り注入なし、stuff率0。
OMNeT入力は元INI/NED/workloadから独立に作成し、DIRの送信時刻・フレーム長・CRC・結果を入力へ転用していない。各ケースのinputs/、omnet/offered.json、omnet/omnetpp.iniに入力を保存。
DIRの通常観測期間に合わせ[0,H)のみ記録。集計期間はイベント枯渇時も設定H。終了理由と内部イベント数は同一視しない。

## 結果（DIR / OMNeT の順）

successはDIRのEOF到達数とFiCoのnative完了数の対照。FiCo完了はIFS込みで、同じEOF定義ではない。

| ケース | 生成 | 完了 | 破棄 | 受信 | SOF順序 | 共通観測 |
|---|---:|---:|---:|---:|---|---|
| [competition](cases/competition/comparison.json) | 2 / 2 | 2 / 2 | 0 / 0 | 4 / 4 | 一致 | 差異 |
| [queue-full](cases/queue-full/comparison.json) | 2 / 2 | 1 / 1 | 1 / 1 | 2 / 2 | 一致 | 差異 |
| [capacity-zero](cases/capacity-zero/comparison.json) | 1 / 1 | 0 / 0 | 1 / 1 | 0 / 0 | 一致 | 一致 |
| [eof-boundary](cases/eof-boundary/comparison.json) | 1 / 1 | 0 / 1 | 0 / 0 | 0 / 2 | 一致 | 差異 |
| [after-eof](cases/after-eof/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [delay-filter](cases/delay-filter/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 1 / 1 | 一致 | 差異 |
| [release-arrival](cases/release-arrival/comparison.json) | 3 / 3 | 3 / 3 | 0 / 0 | 6 / 6 | 差異 | 差異 |
| [mixed-generators](cases/mixed-generators/comparison.json) | 5 / 5 | 0 / 0 | 0 / 0 | 0 / 0 | 一致 | 差異 |
| [baseline](cases/baseline/comparison.json) | 60 / 60 | 60 / 60 | 0 / 0 | 120 / 120 | 一致 | 差異 |
| [contention](cases/contention/comparison.json) | 300 / 300 | 81 / 90 | 72 / 72 | 162 / 180 | 差異 | 差異 |
| [overload](cases/overload/comparison.json) | 1200 / 1200 | 81 / 90 | 1112 / 1104 | 162 / 180 | 差異 | 差異 |
| [mixed-format-extended-wins](cases/mixed-format-extended-wins/comparison.json) | 2 / 2 | 2 / 2 | 0 / 0 | 4 / 4 | 一致 | 差異 |
| [mixed-format-standard-wins](cases/mixed-format-standard-wins/comparison.json) | 2 / 2 | 2 / 2 | 0 / 0 | 4 / 4 | 一致 | 差異 |
| [zero-horizon](cases/zero-horizon/comparison.json) | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 一致 | 一致 |
| [empty-generators](cases/empty-generators/comparison.json) | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 一致 | 一致 |
| [future-only](cases/future-only/comparison.json) | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 | 一致 | 一致 |
| [v0000-500000](cases/v0000-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0000-1000000](cases/v0000-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0000-333333](cases/v0000-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0001-500000](cases/v0001-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0001-1000000](cases/v0001-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0001-333333](cases/v0001-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0002-500000](cases/v0002-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0002-1000000](cases/v0002-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0002-333333](cases/v0002-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0003-500000](cases/v0003-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0003-1000000](cases/v0003-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0003-333333](cases/v0003-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0004-500000](cases/v0004-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0004-1000000](cases/v0004-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0004-333333](cases/v0004-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0005-500000](cases/v0005-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0005-1000000](cases/v0005-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0005-333333](cases/v0005-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0006-500000](cases/v0006-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0006-1000000](cases/v0006-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0006-333333](cases/v0006-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0007-500000](cases/v0007-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0007-1000000](cases/v0007-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0007-333333](cases/v0007-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0008-500000](cases/v0008-500000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0008-1000000](cases/v0008-1000000/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |
| [v0008-333333](cases/v0008-333333/comparison.json) | 1 / 1 | 1 / 1 | 0 / 0 | 2 / 2 | 一致 | 差異 |

## モデルの意味が異なる項目

- DIRは内容依存CRC-15とbit stuffingを計算。FiCoは47/67bit＋payload＋固定率stuffの近似で、設定率0では内容に依存しない。DIRのEOF基底は44/64bitで、別途3bitのintermissionを持つ。
- FiCoはアイドル時の最初の仲裁を1bit時間待つ。DIRはready時刻で仲裁する。後続フレームの送信順や有限キューへの入場結果にも影響し得る。
- FiCoのnative_complete・native_rx_completeはIFS込み。DIRのeof_psと同じ名前にせず、requests.csvにDIR EOF・releaseと並べた。バス占有率はDIRのSOF→releaseとFiCoのSOF→native_completeを同じHで積分する。
- FiCo標準バッファには有限容量がない。今回の容量制限は明示したアダプターの追加機能で、FiCo単体の既定動作との比較ではない。
- 比率は分子・分母もJSONに保存。時刻・件数の比較はps整数で実施し、グラフや丸め表示を一致判定に使わない。

## 対応しないテスト

| 範囲 | 理由 |
|---|---|
| DIR max-events / delta-cycle / committed-prefix failure tests | 内部イベントの粒度とトランザクション境界が異なるため、同じイベント数を同じ物理条件として扱えない。 |
| u64::MAX overflow injection | DIRはu64 ps、OMNeT++は符号付き64bit SimTime。入力範囲と失敗契約が異なる。 |
| CRC / stuffed bitstring conformance vectors | 同じ9フレームを3速度で実行するが、FiCoはCRC・内容依存stuff列を生成しないためcodec一致試験は成立しない。 |
| INI/NED parser, invalid-input, export/atomic-write, viewer, synthetic Snapshot aggregation tests | DIRのAPI・ファイル・UI契約の試験であり、通信シミュレーションへの同一設定対応はない。 |
| GW / multibus CAN runtime scenarios | gateway_compare.pyで複数のFiCo CANバスと外部Gatewayアダプターを使って別途実行・比較する。 |
| CAN FD / Ethernet / AXI / SoC / memory / IPC future specification fixtures | 現在のDIR製品実装はClassical CANとGW。未実装fixtureを実行済みと扱わない。 |

## 証跡と再実行

- report.json: 全ケースの件数、入力一致確認、差分概要、SHA-256・実行版。
- cases/<case>/dir/results.json: DIRの実測結果。
- cases/<case>/omnet/events.csv・run.log・results/: OMNeT++の実測イベントと標準結果。
- cases/<case>/comparison.json・requests.csv: 全要求・全受信・キュー積分・時刻差分。

```bash
python3 tools/omnet_comparison/compare.py --omnet-workspace /home/hideki/Omnet++ --output tmp/omnet-comparison-new
```

既存出力先への上書きは行わない。差異自体は実行失敗と区別し、実行エラーまたは入力対応の不整合があれば非ゼロ終了する。

参照: [OMNeT++ event ordering / SimTime](https://doc.omnetpp.org/omnetpp/manual/#sec:simple-modules:simulation-time)、FiCoのローカルソースとハッシュはreport.json参照。
