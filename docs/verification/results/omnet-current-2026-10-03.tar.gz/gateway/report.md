# DIR / OMNeT++ Gateway comparison

Executed: 35/35

Native FiCo CAN buses, arbitration and approximate frame times are unchanged. Gateway RX/TX/fanout/hop behavior is a test adapter running in the OMNeT++ FES, not the native SignalsAndGateways implementation.

DIR EOF and FiCo completion including IFS are recorded separately; no timestamp or bit-length compensation is used. Inputs are converted from frozen raw files before either output is read.

| Case | Native requests DIR/OMNeT | Copies | Success | RX hold/release/drop DIR | RX hold/release/drop OMNeT | Per-bus SOF order | Common projection |
|---|---:|---:|---:|---|---|---|---|
| [gw-independent](cases/gw-independent/comparison.json) | 2/2 | 1/1 | 3/3 | 0/2/0 | 0/2/0 | equal | different |
| [gw-delay](cases/gw-delay/comparison.json) | 2/2 | 1/1 | 3/3 | 0/2/0 | 0/2/0 | equal | different |
| [gw-queue](cases/gw-queue/comparison.json) | 3/3 | 3/3 | 5/5 | 0/3/0 | 0/3/0 | equal | different |
| [gw-capacity-zero](cases/gw-capacity-zero/comparison.json) | 1/1 | 1/1 | 1/1 | 0/1/0 | 0/1/0 | equal | different |
| [gw-forward-boundary](cases/gw-forward-boundary/comparison.json) | 1/1 | 0/1 | 1/1 | 1/0/0 | 0/1/0 | different | different |
| [gw-eof-boundary](cases/gw-eof-boundary/comparison.json) | 1/1 | 1/1 | 1/2 | 0/1/0 | 0/1/0 | equal | different |
| [gw-no-route](cases/gw-no-route/comparison.json) | 1/1 | 0/0 | 1/1 | 0/1/0 | 0/1/0 | equal | different |
| [gw-rx-filter](cases/gw-rx-filter/comparison.json) | 1/1 | 0/0 | 1/1 | 0/0/0 | 0/0/0 | equal | different |
| [gw-multicast](cases/gw-multicast/comparison.json) | 1/1 | 2/2 | 3/3 | 0/1/0 | 0/1/0 | equal | different |
| [gw-multicast-drop](cases/gw-multicast-drop/comparison.json) | 1/1 | 2/2 | 2/2 | 0/1/0 | 0/1/0 | equal | different |
| [gw-hop](cases/gw-hop/comparison.json) | 1/1 | 2/2 | 3/3 | 0/3/0 | 0/3/0 | equal | different |
| [gw-disjoint-cycle](cases/gw-disjoint-cycle/comparison.json) | 0/0 | 0/0 | 0/0 | 0/0/0 | 0/0/0 | equal | equal |
| [gw-independent-only](cases/gw-independent-only/comparison.json) | 2/2 | 0/0 | 2/2 | 0/0/0 | 0/0/0 | equal | different |
| [gw-queue-queue-boundary](cases/gw-queue-queue-boundary/comparison.json) | 3/3 | 3/3 | 4/4 | 1/2/0 | 0/3/0 | different | different |
| [gw-queue-rx-overflow](cases/gw-queue-rx-overflow/comparison.json) | 4/4 | 3/3 | 6/6 | 0/3/1 | 0/3/1 | equal | different |
| [gw-queue-gw-processing](cases/gw-queue-gw-processing/comparison.json) | 3/3 | 0/0 | 3/3 | 1/0/2 | 1/0/2 | equal | different |
| [gw-queue-tx-processing](cases/gw-queue-tx-processing/comparison.json) | 3/3 | 1/1 | 3/3 | 1/0/2 | 1/0/2 | equal | different |
| [gw-multicast-fanout-held](cases/gw-multicast-fanout-held/comparison.json) | 4/4 | 6/6 | 7/8 | 1/2/1 | 0/3/1 | different | different |
| [gw-multicast-fanout-drained](cases/gw-multicast-fanout-drained/comparison.json) | 4/4 | 6/6 | 10/10 | 0/3/1 | 0/3/1 | equal | different |
| [gw-queue-rx-zero](cases/gw-queue-rx-zero/comparison.json) | 3/3 | 0/0 | 3/3 | 0/0/3 | 0/0/3 | equal | different |
| [gw-no-route-rx-zero](cases/gw-no-route-rx-zero/comparison.json) | 1/1 | 0/0 | 1/1 | 0/0/1 | 0/0/1 | equal | different |
| [gw-queue-default64](cases/gw-queue-default64/comparison.json) | 65/65 | 0/0 | 65/65 | 64/0/1 | 64/0/1 | equal | different |
| [gw-queue-max-rx](cases/gw-queue-max-rx/comparison.json) | 65/65 | 0/0 | 65/65 | 65/0/0 | 65/0/0 | equal | different |
| [gw-multicast-same-priority](cases/gw-multicast-same-priority/comparison.json) | 3/3 | 2/2 | 5/5 | 0/3/0 | 0/3/0 | different | different |
| [gw-multicast-same-priority-permuted](cases/gw-multicast-same-priority-permuted/comparison.json) | 3/3 | 2/2 | 5/5 | 0/3/0 | 0/3/0 | different | different |
| [gw-multicast-first-ready](cases/gw-multicast-first-ready/comparison.json) | 6/6 | 6/6 | 12/12 | 0/6/0 | 0/6/0 | equal | different |
| [gw-multicast-first-ready-permuted](cases/gw-multicast-first-ready-permuted/comparison.json) | 6/6 | 6/6 | 12/12 | 0/6/0 | 0/6/0 | equal | different |
| [gw-delay-renamed-gates](cases/gw-delay-renamed-gates/comparison.json) | 2/2 | 1/1 | 3/3 | 0/2/0 | 0/2/0 | equal | different |
| [gw-buffered-fanout](cases/gw-buffered-fanout/comparison.json) | 10/10 | 12/12 | 20/21 | 0/6/4 | 0/6/4 | different | different |
| [gw-native-forward-at](cases/gw-native-forward-at/comparison.json) | 1/1 | 0/0 | 1/1 | 1/0/0 | 1/0/0 | equal | different |
| [gw-native-forward-after](cases/gw-native-forward-after/comparison.json) | 1/1 | 0/1 | 1/1 | 1/0/0 | 0/1/0 | equal | different |
| [gw-native-sof-at](cases/gw-native-sof-at/comparison.json) | 3/3 | 3/3 | 3/3 | 1/2/0 | 1/2/0 | equal | different |
| [gw-native-sof-after](cases/gw-native-sof-after/comparison.json) | 3/3 | 3/3 | 3/4 | 1/2/0 | 0/3/0 | different | different |
| [gw-native-complete-at](cases/gw-native-complete-at/comparison.json) | 1/1 | 0/0 | 0/0 | 0/0/0 | 0/0/0 | equal | different |
| [gw-native-complete-after](cases/gw-native-complete-after/comparison.json) | 1/1 | 0/1 | 0/1 | 0/0/0 | 0/1/0 | equal | different |

## Validation and scope

Every real native event is checked for raw payload/ID/format, lineage, sequence, same-bus delivery, configured processing/channel delays, TX admission, RX capacity and outstanding-egress conservation before comparison.

Invalid-input tests, DIR internal event-limit/transaction/overflow contracts, codec bitstream assertions, output publication, viewer and unimplemented model fixtures have no equivalent physical experiment. They are not reported as simulated in OMNeT++.
